package com.saga_egovernance.service_C;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceCApplicationTests {

	@Test
	void contextLoads() {
	}

}
