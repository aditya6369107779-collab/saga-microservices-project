package com.saga_egovernance.service_c;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController
@RequestMapping("/serviceC")
public class ServiceCController {

    @GetMapping("/execute")
    public String execute() {
        if (Math.random() < 0.9) {
            return "SUCCESS";
        } else {
            return "FAIL";
        }
    }
}