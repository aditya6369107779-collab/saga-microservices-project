package com.saga_egovernance.service_A;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController
@RequestMapping("/serviceA")
public class ServiceAController {

    @GetMapping("/execute")
    public String execute() {
        if (Math.random() < 0.8) {
            return "SUCCESS";
        } else {
            return "FAIL";
        }
    }
}