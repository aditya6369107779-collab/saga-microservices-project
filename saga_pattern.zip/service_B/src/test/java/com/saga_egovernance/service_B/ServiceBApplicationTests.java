package com.saga_egovernance.service_B;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceBApplicationTests {

	@Test
	void contextLoads() {
	}

}
