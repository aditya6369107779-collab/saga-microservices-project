package com.saga_egovernance.service_b;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController
@RequestMapping("/serviceB")
public class ServiceBController {

    @GetMapping("/execute")
    public String execute() {
        if (Math.random() < 0.7) {
            return "SUCCESS";
        } else {
            return "FAIL";
        }
    }
}