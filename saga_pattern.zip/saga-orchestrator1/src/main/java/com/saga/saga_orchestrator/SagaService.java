package com.saga.saga_orchestrator;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class SagaService {

    private final RestTemplate restTemplate = new RestTemplate();

    public String executeSaga() {

        String a = restTemplate.getForObject("http://localhost:8081/serviceA/execute", String.class);
        System.out.println("A → " + a);

        if (!a.equals("SUCCESS")) return "Failed at A";

        String b = restTemplate.getForObject("http://localhost:8082/serviceB/execute", String.class);
        System.out.println("B → " + b);

        if (!b.equals("SUCCESS")) return "Failed at B (Compensate A)";

        String c = restTemplate.getForObject("http://localhost:8083/serviceC/execute", String.class);
        System.out.println("C → " + c);

        if (!c.equals("SUCCESS")) return "Failed at C (Compensate B & A)";

        return "SUCCESS 🎉";
    }
}