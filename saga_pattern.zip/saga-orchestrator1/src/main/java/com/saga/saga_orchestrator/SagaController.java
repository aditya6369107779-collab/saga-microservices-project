package com.saga.saga_orchestrator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SagaController {

    @Autowired
    private SagaService sagaService;

    @GetMapping("/home")
    public String test() {
        return "WORKING";
    }

    @GetMapping("/start")
    public String start() {
        return sagaService.executeSaga();
    }
}